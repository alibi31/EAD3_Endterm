package net.alterapp.miniproject3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
//@EnableSwagger2
public class MiniprojectApplication {
    public static void main(String[] args) {
        SpringApplication.run(MiniprojectApplication.class, args);
    }

}